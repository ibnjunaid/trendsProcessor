import src.scraper.get_trends as scraper
import src.preprocessor.pre as preprocessor


def scrap_hashtag(trend_hashtag):
    tweets = scraper.retrive_tweets(trend_hashtag)

    top_urls = preprocessor.extract_top_urls(tweets)
    top_mentions = preprocessor.extract_top_mentions(tweets)
    top_hashtags = preprocessor.extract_top_hashtags(tweets)

    return {
        'top_urls': top_urls,
        'top_mentions': top_mentions,
        'top_similar_hashtags': top_hashtags
    }
